/* INNOVATECH AFRIKA — V9 — Interactions légères */
(function(){
  'use strict';

  // Reveal au scroll
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){ e.target.classList.add('is-visible'); io.unobserve(e.target); }
    });
  }, {threshold:0.12, rootMargin:'0px 0px -60px 0px'});

  document.querySelectorAll('.expertise-card,.secteur-card,.agent-card,.humains-value,.archi-layer')
    .forEach(el=>{
      el.style.opacity='0';
      el.style.transform='translateY(16px)';
      el.style.transition='opacity .6s cubic-bezier(.2,.7,.3,1), transform .6s cubic-bezier(.2,.7,.3,1)';
      io.observe(el);
    });

  const style = document.createElement('style');
  style.textContent = '.is-visible{opacity:1!important;transform:translateY(0)!important}';
  document.head.appendChild(style);

  // Nav shadow au scroll
  const nav = document.querySelector('.nav');
  if(nav){
    const onScroll = () => {
      if(window.scrollY > 10) nav.style.boxShadow = '0 2px 12px rgba(0,0,0,.06)';
      else nav.style.boxShadow = 'none';
    };
    window.addEventListener('scroll', onScroll, {passive:true});
    onScroll();
  }
})();
